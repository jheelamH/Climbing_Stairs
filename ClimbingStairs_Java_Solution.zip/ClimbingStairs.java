
// ClimbingStairs.java
public class ClimbingStairs {

    // Function to count ways using Dynamic Programming
    public static int climbStairs(int n) {
        if (n <= 2) return n; // Base cases

        int prev1 = 2; // ways to reach step 2
        int prev2 = 1; // ways to reach step 1
        int current = 0;

        for (int i = 3; i <= n; i++) {
            current = prev1 + prev2; // Recurrence relation
            prev2 = prev1; // shift window
            prev1 = current;
        }
        return current;
    }

    public static void main(String[] args) {
        int n = 5; // Example input
        System.out.println("Number of ways to climb " + n + " stairs: " + climbStairs(n));
    }
}
